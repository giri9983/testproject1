﻿using System.Web;
using System.Web.Optimization;

namespace TestProjectWebApp
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/js/bootstrap.js",
                      "~/js/app.js",
                      "~/js/select2/select2.min.js",
                      "~/js/slimscroll/jquery.slimscroll.min.js",
                      "~/js/app.plugin.js",
                      "~/js/jquery.min.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                     "~/css/bootstrap.css",
                     "~/css/font-awesome.min.css",
                     "~/js/select2/select2.css",
                     "~/js/select2/theme.css",
                     "~/css/font.css",
                     "~/css/app.css",
                     "~/css/animate.css"));
        }
    }
}
