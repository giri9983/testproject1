﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using TestProjectWebApp.Controllers.Shared;
using TestProjectWebApp.Models;
using TestProjectDBAccess.Models;
using TestProjectDBAccess.Repositories;



namespace TestProjectWebApp.Controllers
{
    public class HomeController : ApplicationController<LogOnModel>
    {

        private IDBAccessRepository db;  
  
        public HomeController()   
        {  
            db = new DBAccessRepository(new TestProjectDBAccess.Models.DBAccessContext());  
        }
        public HomeController(IDBAccessRepository db1)   
        {  
            db = db1;  
        }  

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Devices(string DType, string Org, string Site)
        {
            var dev = db.GetAllDevices().ToList();
            if (DType != null && DType != "")
            {
                List<string> dtsids = new List<string>();
                string[] ids = DType.Split(',');
                foreach (var it in ids)
                {
                    dtsids.Add(Convert.ToString(it));
                }

                dev = dev.Where(x => dtsids.Contains(x.DeviceType)).ToList();
                //dev = dev.Where(x => x.DeviceType == DType).ToList();
            }
            if (Org != null && Org != "")
            {
                List<string> dtsids = new List<string>();
                string[] ids = Org.Split(',');
                foreach (var it in ids)
                {
                    dtsids.Add(Convert.ToString(it));
                }

                dev = dev.Where(x => dtsids.Contains(x.Organization)).ToList();

                //dev = dev.Where(x => x.Organization == Org).ToList();
            }
            if (Site != null && Site != "")
            {
                List<string> dtsids = new List<string>();
                string[] ids = Site.Split(',');
                foreach (var it in ids)
                {
                    dtsids.Add(Convert.ToString(it));
                }

                dev = dev.Where(x => dtsids.Contains(x.DeviceSite)).ToList();

                //dev = dev.Where(x => x.DeviceSite == Site).ToList();
            }
            ViewBag.Devices = dev;
            return PartialView();
        }
        public ActionResult Devices_Binding([DataSourceRequest]DataSourceRequest request)
        {
            var dev = db.GetAllDevices().ToList();            
            return Json(dev.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }
        public ActionResult DeviceFilters(int? TypeID)
        {
            var dev = db.GetAllDevices().ToList();
            ViewBag.Devices = dev;
            return PartialView();
        }

        public ActionResult DevicesFilter_Labels(string DType, string Org, string Site)
        {
            ViewBag.DType = DType;
            ViewBag.Org = Org;
            ViewBag.Site = Site;
            return PartialView();
        }



    }
}