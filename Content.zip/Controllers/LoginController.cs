﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Dynamic;
using System.Web.Routing;
using TestProjectWebApp.Controllers.Shared;
using TestProjectWebApp.Models;

using TestProjectDBAccess.Models;
using TestProjectDBAccess.Repositories;

namespace TestProjectWebApp.Controllers
{
    public class LoginController : ApplicationController<LogOnModel>
    {
        private IDBAccessRepository db;  
  
        public LoginController()   
        {  
            db = new DBAccessRepository(new TestProjectDBAccess.Models.DBAccessContext());  
        }
        public LoginController(IDBAccessRepository db1)   
        {  
            db = db1;  
        }  
        // GET: /Login/



        public ActionResult Login()
        {
            return View();
        }



        // POST: /Branch/Create

        [HttpPost]
        public ActionResult Login(User u)
        {
            if (ModelState.IsValid)
            {

                var UsersResult1 = db.GetAllUsers().Where(x => x.UserName == u.UserName).ToList();
                if (UsersResult1.Count() == 0)
                {
                    ModelState.AddModelError("UserName", "Invalid User name");
                }
                else
                {

                    var UsersResult2 = UsersResult1.Where(x => x.UserName == u.UserName && x.Password == u.Password).FirstOrDefault();
                    if (UsersResult2 != null)
                    {

                        LogOnModel model = new Models.LogOnModel();

                        /*Set model to session*/

                        model.RoleID = UsersResult2.RoleID;
                        model.UserID = UsersResult2.UserID;
                        model.FirsrName = UsersResult2.FirstName;
                        model.MiddleName = UsersResult2.MiddleName;
                        model.UserName = UsersResult2.UserName;
                        model.Password = UsersResult2.Password;
                        SetLogOnSessionModel(model);



                        return RedirectToAction("Index", "Home", "Index.cshtml");

                    }
                    else
                    {
                        ModelState.AddModelError("Password", "Invalid Password");
                    }
                }
            }
            return View();
        }





    }
}

