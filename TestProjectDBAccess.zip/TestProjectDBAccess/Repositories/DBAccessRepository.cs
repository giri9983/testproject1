﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using TestProjectDBAccess.Models;

namespace TestProjectDBAccess.Repositories
{
    public class DBAccessRepository : IDBAccessRepository, IDisposable
    {
        private readonly DBAccessContext _context;

        public DBAccessRepository(DBAccessContext context)   
        {  
            _context = context;  
        }  
  
        public IEnumerable<User> GetAllUsers()  
        {
            return _context.Users.ToList();  
        }  
        public User GetUserById(int UserID)  
        {
            return _context.Users.Find(UserID);  
        }

        public int AddUser(User userEntity)  
          
        {  
            int result = -1;

            if (userEntity != null)  
            {
                _context.Users.Add(userEntity);  
                _context.SaveChanges();
                result = userEntity.UserID;  
            }  
            return result;  
  
        }
        public int UpdateUser(User userEntity)   
        {  
            int result = -1;

            if (userEntity != null)   
            {
                _context.Entry(userEntity).State = EntityState.Modified;  
                _context.SaveChanges();
                result = userEntity.UserID;  
            }  
            return result;  
        }  
        public void DeleteUser(int UserID)   
        {
            User userEntity = _context.Users.Find(UserID);
            _context.Users.Remove(userEntity);  
            _context.SaveChanges();  
  
        }

        public IEnumerable<Device> GetAllDevices()
        {
            return _context.Devices.ToList();
        }
        public Device GetDeviceById(int DeviceID)
        {
            return _context.Devices.Find(DeviceID);
        }

        public int AddDevice(Device DeviceEntity)
        {
            int result = -1;

            if (DeviceEntity != null)
            {
                _context.Devices.Add(DeviceEntity);
                _context.SaveChanges();
                result = DeviceEntity.DeviceID;
            }
            return result;

        }
        public int UpdateDevice(Device DeviceEntity)
        {
            int result = -1;

            if (DeviceEntity != null)
            {
                _context.Entry(DeviceEntity).State = EntityState.Modified;
                _context.SaveChanges();
                result = DeviceEntity.DeviceID;
            }
            return result;
        }
        public void DeleteDevice(int DeviceID)
        {
            Device DeviceEntity = _context.Devices.Find(DeviceID);
            _context.Devices.Remove(DeviceEntity);
            _context.SaveChanges();

        }

        public IEnumerable<Group> GetAllGroups()
        {
            return _context.Groups.ToList();
        }
        public Group GetGroupById(int GroupID)
        {
            return _context.Groups.Find(GroupID);
        }

        public int AddGroup(Group GroupEntity)
        {
            int result = -1;

            if (GroupEntity != null)
            {
                _context.Groups.Add(GroupEntity);
                _context.SaveChanges();
                result = GroupEntity.GroupID;
            }
            return result;

        }
        public int UpdateGroup(Group GroupEntity)
        {
            int result = -1;

            if (GroupEntity != null)
            {
                _context.Entry(GroupEntity).State = EntityState.Modified;
                _context.SaveChanges();
                result = GroupEntity.GroupID;
            }
            return result;
        }
        public void DeleteGroup(int GroupID)
        {
            Group GroupEntity = _context.Groups.Find(GroupID);
            _context.Groups.Remove(GroupEntity);
            _context.SaveChanges();

        }

        public IEnumerable<Role> GetAllRoles()
        {
            return _context.Roles.ToList();
        }
        public Role GetRoleById(int RoleID)
        {
            return _context.Roles.Find(RoleID);
        }

        public int AddRole(Role RoleEntity)
        {
            int result = -1;

            if (RoleEntity != null)
            {
                _context.Roles.Add(RoleEntity);
                _context.SaveChanges();
                result = RoleEntity.RoleID;
            }
            return result;

        }
        public int UpdateRole(Role RoleEntity)
        {
            int result = -1;

            if (RoleEntity != null)
            {
                _context.Entry(RoleEntity).State = EntityState.Modified;
                _context.SaveChanges();
                result = RoleEntity.RoleID;
            }
            return result;
        }
        public void DeleteRole(int RoleID)
        {
            Role RoleEntity = _context.Roles.Find(RoleID);
            _context.Roles.Remove(RoleEntity);
            _context.SaveChanges();

        }  
  
        private bool disposed = false;  
  
        protected virtual void Dispose(bool disposing)   
        {  
            if (!this.disposed)  
            {  
                if (disposing)   
                {  
                    _context.Dispose();  
                }  
            }  
            this.disposed = true;  
        }  
  
        public void Dispose()   
        {  
            Dispose(true);  
            
            GC.SuppressFinalize(this);  
        }  
    }
}