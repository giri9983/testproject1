﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProjectDBAccess.Models;

namespace TestProjectDBAccess.Repositories
{
    public interface IDBAccessRepository : IDisposable
    {
        IEnumerable<User> GetAllUsers();
        User GetUserById(int UserID);
        int AddUser(User userEntity);
        int UpdateUser(User userEntity);
        void DeleteUser(int UserID);

        IEnumerable<Device> GetAllDevices();
        Device GetDeviceById(int DeviceID);
        int AddDevice(Device DeviceEntity);
        int UpdateDevice(Device DeviceEntity);
        void DeleteDevice(int DeviceID);

        IEnumerable<Group> GetAllGroups();
        Group GetGroupById(int GroupID);
        int AddGroup(Group GroupEntity);
        int UpdateGroup(Group GroupEntity);
        void DeleteGroup(int GroupID);

        IEnumerable<Role> GetAllRoles();
        Role GetRoleById(int RoleID);
        int AddRole(Role RoleEntity);
        int UpdateRole(Role RoleEntity);
        void DeleteRole(int RoleID);  
    }
}
