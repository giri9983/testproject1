﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestProjectDBAccess;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using TestProjectWebApp.Controllers.Shared;
using TestProjectWebApp.Models;


namespace TestProjectWebApp.Controllers
{
    public class HomeController : ApplicationController<LogOnModel>
    {

        TestProjectDBEntities db = new TestProjectDBEntities();
        //
        // GET: /Home/
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult Devices(string DType, string Org, string Site)
        {
            var dev = db.Devices.ToList();
            if (DType != null && DType != "")
            {
                dev = dev.Where(x => x.DeviceType == DType).ToList();
            }
            if (Org != null && Org != "")
            {
                dev = dev.Where(x => x.Organization == Org).ToList();
            }
            if (Site != null && Site != "")
            {
                dev = dev.Where(x => x.DeviceSite == Site).ToList();
            }
            ViewBag.Devices = dev;
            return PartialView();
        }

      
        public ActionResult Devices_Binding([DataSourceRequest]DataSourceRequest request)
        {
            var dev = db.Devices.ToList();
            return Json(dev.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }
        public ActionResult DeviceFilters(int? TypeID)
        {
            var dev = db.Devices.ToList();
            ViewBag.Devices = dev;
            return PartialView();
        }
    }
}